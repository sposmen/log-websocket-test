require 'rubygems'
require 'eventmachine'
require 'open-uri'
require 'em-http-request'

def connect_to_ws
 http = EventMachine::HttpRequest.new("ws://127.0.0.1:8081/websocket").get :timeout => 0
   http.errback { |msg|
     puts msg
   }
   http.callback {
    puts "connected"
  }
  http.stream {
    puts "received reply from server"
  }
end

EM.epoll = true
EM.set_descriptor_table_size(10000)
EM.run do
  10_000.times do |i|
    puts i
    connect_to_ws
  end
end
