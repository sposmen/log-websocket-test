require 'rubygems'
require 'eventmachine'
require 'em-websocket'
require 'faker'

class ServerHandler

  def initialize
    @clients = {}
  end

  def send_message_to_users(message)
    @clients.each do |id, client|
      client.send(message) #leaking memory
    end
  end

  def add_client(ws)
    @clients[rand(10000000)] = ws
  end

  def remove_client(id)
    @clients.delete id
  end

  def run
    puts "starting server"

    EventMachine.epoll = true
    EventMachine.set_descriptor_table_size(10000)
    EventMachine.run {

      EventMachine::WebSocket.start(:host => "127.0.0.1", :port => 8081) do |ws|
        client_id = 0
        ws.onopen do
          puts "WebSocket connection open"
          client_id = add_client(ws)
        end

        ws.onclose do
          remove_client(client_id)
        end
      end

      EventMachine.add_periodic_timer(3) {
        text = Faker::Lorem.paragraphs(200).join
        send_message_to_users(text)
      }
    }
  end

end

ServerHandler.new.run